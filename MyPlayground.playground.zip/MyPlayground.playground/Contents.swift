import UIKit


//let firstConst : Int = 1
//let secondConst : Double = 1
//let thirdConst  : String = ""
//let foutConst : Bool = true
//let fifthConst : Character = "f"


//var firsVar: Int = 1
//var secondVar : Double = 1
//var thirdVar  : String = ""
//var foutVar : Bool = true
//var fifthVar : Character = "f"




 //var a = 10
 //var b = 0
 //
 //if a >= 7 {
 //    b += 7
 //} else  {
 //    b -= 7
 //}
 //
 //
 //if a + b > 15  && b >= 7 {
 //    b *= 2
 //} else {
 //    b += 3
 //}
 //
 //switch a {
 //case 0 ... 7 :
 //    print (a + b)
 //case 8 ... 20 :
 //    print (a - b)
 //case 21 ... 50 :
 //    print (a * b)
 //default :
 //    print ("нет диапазона")
 //}
 //
 //
 //
 //if a > 10  && b < 20  && a + b > 15 {
 //    b -= 10
 //} else if a - b < 20{
 //    print (b)
 //}else {
 //    b += 7
 //}
 //
 //
 //if a + b > 20 || b - a < 7 {
 //    print (a)
 //} else  {
 //    print (b)
 //}
 //
 //
  //if (a > 15 || b < 7) && a + b - 7 != 17 {
 //    print (a)
 //} else {
 //    print (b)
 //}
 //
 //for i in 0 ... 10 where  !i.isMultiple(of: 2)   {
 //    print (i)
 //}
 //
 //
 //// zadanie 2 //
 //
 //
 //while  a  != 50 {
 //    b -= 2
 //    a += 1
 //}
 //
 //
 //
 //for i in 3 ... 5 {
 //    b += i
 //}
 //
 //
 //
 //for i in 1 ... 10 {
 //    if a + i > b {
 //        b += 30
 //    }else {
 //        b -= 10
 //    }
 //}
 //
 //var k = 5
 //for i in 20 ..< 30 {
 //    if i > 25 {
 //        k -= 4
 //    }else {
 //        k += 10
 //    }
 //}
 //
 ////k > 20 ? k - 10 : k + 1//
 //k = k > 20 ? k - 10 : k + 1
 //
 //
 //
 //while k != 40 {
 //    b -= 3
 //    a += 10
 //    k += 1
 //    switch a {
 //    case 10...30 :
 //        print (a + b)
 //    case 31...50 :
 //        print (a - b)
 //    case 51...10 :
 //        print (a * b )
 //    default :
 //        continue
 //    }
 //} //



//DZ 1 zadanie
for i in 0 ... 10 where  i.isMultiple(of: 2)   {
    print (i)
}
 // zadanie 2
var a = 7
var b = 20
if a * b > 10{
    print (a)
} else {
    print (b)
}

// zadanie 3
var k = 9

for i in 10...50 where i % 2 != 0 {
    if (i + k) % 2 == 0 {
        k += 2
    } else {
        print ("Next")
        continue
    }
}
// zadanie 4
for i in 10...50 where i % 2 != 0 {
    if (i + k) % 2 == 0 {
        k += 1
    } else {
        print ("Next")
        break
    }
}
